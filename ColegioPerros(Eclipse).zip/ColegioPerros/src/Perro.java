
public class Perro {

    private String nombre;
    private String raza;
    private String localidad;
    private String cedula;
    private String nombreDue�o;
    private String telefonoContacto;
    private String diaAsistencia;

    public Perro(String nombre, String raza, String localidad, String cedula, String nombreDue�o, String telefonoContacto, String diaAsistencia) {
        this.nombre = nombre;
        this.raza = raza;
        this.localidad = localidad;
        this.cedula = cedula;
        this.nombreDue�o = nombreDue�o;
        this.telefonoContacto = telefonoContacto;
        this.diaAsistencia = diaAsistencia;
    }

    public Perro() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombreDue�o() {
        return nombreDue�o;
    }

    public void setNombreDue�o(String nombreDue�o) {
        this.nombreDue�o = nombreDue�o;
    }

    public String getTelefonoContacto() {
        return telefonoContacto;
    }

    public void setTelefonoContacto(String telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    public String getDiaAsistencia() {
        return diaAsistencia;
    }

    public void setDiaAsistencia(String diaAsistencia) {
        this.diaAsistencia = diaAsistencia;
    }

    public void listarPerro() {
        System.out.println("-------Informacion------");
        System.out.println("Nombre: "+nombre);
        System.out.println("Raza: "+raza);        
        System.out.println("Localidad: "+localidad);
        System.out.println("Cedula: "+cedula);
        System.out.println("Nombre del Dueño: "+nombreDue�o);
        System.out.println("Telefono: "+telefonoContacto);
        System.out.println("Dia de Asistencia: "+diaAsistencia);
        System.out.println("-------------------------");
    }

}
