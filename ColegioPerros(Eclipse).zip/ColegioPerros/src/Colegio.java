
import java.util.ArrayList;

public class Colegio {
    
    private ArrayList<Perro> lista;
    
    public Colegio(){
        lista = new ArrayList();        
    }
    
    public void insertarPerro(Perro p){
        lista.add(p);
    }
    
    public Perro obtenerPerro(int indice){
        if(indice > 0 && indice <=lista.size()){
            return lista.get(indice-1);
        }else{
            return null;
        }
    }
    
    public void listarPerrosPorLocalidad(String localidad){
        for(Perro p: lista){
            if(p.getLocalidad().equals(localidad)){
                p.listarPerro();
            }
        }
    }
    
    
}
