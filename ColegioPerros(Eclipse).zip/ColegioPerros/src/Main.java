
import java.util.Scanner;

public class Main {

    public static void main(String[] Args) {
        Colegio colegio = new Colegio();
        inicializarColegio(colegio);
        Scanner s = new Scanner(System.in);
        String opcion = "";
        while (!opcion.equals("4")) {
            System.out.println("Menu principal");
            System.out.println("1. Registrar Perro");
            System.out.println("2. Consultar Perro");
            System.out.println("3. Consultar Perros por Localidad");
            System.out.println("4. Salir");
            System.out.print("Opcion: ");
            opcion = s.nextLine();
            switch (opcion) {
                case "1":
                    Perro p = new Perro();
                    System.out.print("Nombre: ");
                    p.setNombre(s.nextLine());
                    System.out.print("Raza: ");
                    p.setRaza(s.nextLine());
                    System.out.print("Localidad: ");
                    p.setLocalidad(s.nextLine());
                    System.out.print("Cedula: ");
                    p.setCedula(s.nextLine());
                    System.out.print("Nombre del Dueño: ");
                    p.setNombreDue�o(s.nextLine());
                    System.out.print("Telefono: ");
                    p.setTelefonoContacto(s.nextLine());
                    System.out.print("Dia de Asistencia: ");
                    p.setDiaAsistencia(s.nextLine());
                    colegio.insertarPerro(p);
                    System.out.println("Informacion registrada.");
                    break;
                case "2":
                    System.out.print("Ingrese el numero del perro a consultar: ");
                    int indice = Integer.parseInt(s.nextLine());
                    Perro tmp = colegio.obtenerPerro(indice);
                    if(tmp == null){
                        System.out.println("El perro no pudo ser encontrado.");
                    }else{
                        tmp.listarPerro();
                    }
                    break;
                case "3":
                    System.out.print("Ingrese la localidad a consultar: ");
                    colegio.listarPerrosPorLocalidad(s.nextLine());
                    break;
            }
        }

    }

    private static void inicializarColegio(Colegio colegio) {
        Perro p1 = new Perro("Manchas", "Yorkie", "Suba", "10101", "Lina", "310-339-3222", "Miercoles");
        Perro p2 = new Perro("Copito", "Golden Retriever", "Suba", "10102", "Juana", "320-340-8745", "Jueves");
        Perro p3 = new Perro("Luna", "Labrador", "Teusaquillo", "10103", "Catalina", "311-341-6666", "Martes");
        Perro p4 = new Perro("Mateo", "Pastor Aleman", "Bosa", "10104", "Cecilia", "311-342-8794", "Lunes");
        Perro p5 = new Perro("Killer", "Chihuahua", "Suba", "10105", "Juan", "317-343-1564", "Lunes");
        Perro p6 = new Perro("Frida", "Pincher", "Bosa", "10106", "Jose", "320-344-4632", "Martes");
        Perro p7 = new Perro("Pluto", "Galgo italiano", "Bosa", "10107", "Pedro", "310-345-4987", "Lunes");
        Perro p8 = new Perro("Kripto", "Pekines", "Bosa", "10108", "Carlos", "317-346-9632", "Viernes");
        Perro p9 = new Perro("Ronchas", "Beagle", "Kennedy", "10109", "Giaccomo", "320-347-2587", "Viernes");
        Perro p10 = new Perro("Felix", "Cocker Spaniel", "Kennedy", "10110", "Jaime", "317-348-7145", "Martes");
        colegio.insertarPerro(p1);
        colegio.insertarPerro(p2);
        colegio.insertarPerro(p3);
        colegio.insertarPerro(p4);
        colegio.insertarPerro(p5);
        colegio.insertarPerro(p6);
        colegio.insertarPerro(p7);
        colegio.insertarPerro(p8);
        colegio.insertarPerro(p9);
        colegio.insertarPerro(p10);
    }

}
